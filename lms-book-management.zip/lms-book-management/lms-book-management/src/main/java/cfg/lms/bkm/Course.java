package cfg.lms.bkm;

import lombok.Data;

@Data
public class Course {
	private int id;
	private String cname;

}
