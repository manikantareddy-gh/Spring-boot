package cfg.lms.bkm;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;

public class Employee {
	public Employee() {
		System.out.println("Employee Constructor");
	}
	
	@PostConstruct
	public void initMethod() {
		System.out.println("init method");
	}
	
	@PreDestroy
	public void destroy() {
		
	}

}
