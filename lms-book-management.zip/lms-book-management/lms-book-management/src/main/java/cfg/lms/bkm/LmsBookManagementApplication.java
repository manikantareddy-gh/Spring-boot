package cfg.lms.bkm;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.support.ClassPathXmlApplicationContext;

@SpringBootApplication
public class LmsBookManagementApplication {

	public static void main(String[] args) {
//		// 5 here we added ConfigurableApplicationContext context =
		           //ConfigurableApplicationContext context = SpringApplication.run(LmsBookManagementApplication.class, args);
//		// 6 here context.getBean is used to create an object
//		Author author = context.getBean(Author.class);
//		author.setAid(1);
//		author.setName("durga");
//
//		Book book = context.getBean(Book.class);
//		book.setAuthor(author);
//		book.setBookId(2);
//		book.setTitle("Java");
//
//		System.out.println(author.getAid());
//		System.out.println(author.getName());

		// 17
//		User user1 = context.getBean(Customer.class);
//		user1.setName("durga");
//		user1.setUserId(2);
//
//		User user2 = context.getBean(Librarian.class);
//		user2.setName("sundar");
//		user2.setUserId(2);
//
//		Book book1 = context.getBean(Book.class);
//		System.out.println(book1.getUser().getName());
//
//		Book book2 = context.getBean(Book.class);
//		System.out.println(book2.getUser().getName());
		
		
		
		
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		Student st = context.getBean(Student.class);
		System.out.println("student id: " + st.getId());
		System.out.println("student name: " + st.getName());
		

	}

}
