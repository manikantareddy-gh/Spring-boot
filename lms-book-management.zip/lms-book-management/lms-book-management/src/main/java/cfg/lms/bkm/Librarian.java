package cfg.lms.bkm;

import org.springframework.stereotype.Component;

import lombok.Data;

//11 for qualifer 
@Component("librarian")
// 8 created an librarian child
@Data
public class Librarian extends User {
	//15 created an variable salary
	private double salary;

}
