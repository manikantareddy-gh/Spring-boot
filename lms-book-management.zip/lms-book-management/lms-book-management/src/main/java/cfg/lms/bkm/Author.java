package cfg.lms.bkm;
import org.springframework.stereotype.Component;

import lombok.Data;

@Component
@Data // helps for getters and setters with out creating them
//3 created an author class
public class Author {
	private int aid;
	private String name;

}
