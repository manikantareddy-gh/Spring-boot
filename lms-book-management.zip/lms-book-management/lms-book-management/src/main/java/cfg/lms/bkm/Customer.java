package cfg.lms.bkm;

import org.springframework.stereotype.Component;

import lombok.Data;

//12 for qualifer
@Component("customer")
// 9 created an customer child 
@Data
public class Customer extends User {
	// 16 created and variable email
	private String email;

}
