package cfg.lms.bkm;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import lombok.Data;

@Component
@Data
public class Book {
	private int bookId;
	private String title;
	// 4
	@Autowired // annotation used on the top of child object (link with main class with
				// dependet class)
	private Author author;

	// 10
	@Autowired
	// 13 here i assigned qualifier beacuse ther is an ambigvity problem which child class when there are more
	// has to to refer here qualifer will helps
	@Qualifier("customer")
	private User user;
	

}
