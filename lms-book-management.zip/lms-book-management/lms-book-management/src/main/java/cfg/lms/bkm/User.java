package cfg.lms.bkm;

import org.springframework.stereotype.Component;

import lombok.Data;

// 7
@Data
@Component
public class User {
	//14 created an variables
	private int userId;
	private String name;

}
