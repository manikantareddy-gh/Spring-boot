import { AbstractControl } from "@angular/forms";
//abstractControl is used to create a custom validator and it is used to access the form control
export function nospaceValidator(control:AbstractControl){
    if(control.value!=null && control.value.includes(' ')){
        return {'nospace': true}
    }else{
        return null
    }
}