import { Component } from '@angular/core';
import { BookService } from '../services/book-service';

@Component({
  selector: 'app-book',
  imports: [],
  templateUrl: './book.html',
  styleUrl: './book.css'
})
export class Book {
  constructor(private bookService: BookService) { }
  showbooks() {
    this.bookService.getBooks().subscribe(response=>{
      console.log(response);
    })
  }

}


