package cfg.lms.lum;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(schema = "library", name="book")
@Data
public class BookEntity {
	@Id
	@Column(name="uid")
	private int id;
	
	@Column(name="book_title")
	private String title;
	
	@Column(name="book_author")
	private String author;

}
