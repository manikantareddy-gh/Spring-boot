package cfg.lms.lum;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(schema = "library", name = "employee")
@Data
public class EmployeeEntity {
	@Id
	private int id;
	@Column
	private String name;
//	@OneToOne //(fetch = FetchType.LAZY)
//	@JoinColumn(name = "adrid", referencedColumnName = "id")
//	private AddressEntity adrs;
	
	
	//many employees have same address
//	@ManyToOne
//	@JoinColumn(name = "adrid", referencedColumnName = "id")
//	private AddressEntity adrs;
}
