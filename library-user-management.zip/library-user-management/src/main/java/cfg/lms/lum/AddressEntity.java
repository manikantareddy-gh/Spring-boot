package cfg.lms.lum;

import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(schema  = "library", name="address")
@Data
public class AddressEntity {
	@Id
	private int id;
	@Column
	private String location;
	
	// one address assigned to many employees
//	@OneToMany(mappedBy = "adrs")
//	private List<EmployeeEntity> employees;
	

}
