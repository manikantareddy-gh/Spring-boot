package cfg.lms.lum;

import java.util.Optional;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class LibraryUserManagementApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext context = SpringApplication.run(LibraryUserManagementApplication.class, args);
//		BookRepository repo = context.getBean(BookRepository.class);
//		List<BookEntity> books = repo.findAll();
//		List<BookEntity> books = repo.findByTitle("react");
//		for(BookEntity book : books)
//		{
//			System.out.println(book.getTitle()+"---"+book.getAuthor());
//		}

//		List<BookEntity> books = repo.findByTitleOrAuthor("google");
//		for(BookEntity book : books)
//		{
//			System.out.println(book.getTitle()+"---"+book.getAuthor());
//		}

//		for (BookEntity book : books) {
//			System.out.println(book.getBook_id() + " " + book.getBook_title() + " " + book.getBook_author());
//		}

		// search book by id
//		Optional<BookEntity> book = repo.findById("3");
//		if (book.isPresent()) {
//			System.out.println(book.get().getBook_title() + " -->  " + book.get().getBook_author());
//		}

		// to add book in the table and update book in the table
//		BookEntity book = new BookEntity();
//		book.setId(9);
//		book.setTitle("jenkins");
//		book.setAuthor("devops");
//
//		repo.save(book);

//		repo.deleteById("9");
//		repo.deleteByTitle("java");
//		repo.deleteByTitleOrAuthor("jdbc","google");

		EmployeeRepository repo = context.getBean(EmployeeRepository.class);
		Optional<EmployeeEntity> employee = repo.findById(1);
		if (employee.isPresent()) {
			System.out.println("location: " + employee.get().getAdrs().getLocation());
			System.out.println();
		}

	}

}
