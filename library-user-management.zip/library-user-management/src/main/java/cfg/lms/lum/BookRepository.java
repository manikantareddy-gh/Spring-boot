package cfg.lms.lum;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import jakarta.transaction.Transactional;

@Repository
@Transactional
public interface BookRepository extends JpaRepository<BookEntity, String> {

	void deleteByTitle(String string);

//	void deleteByTitleOrAuthor(String title, String author);

//	@Query("from BookEntity b where author=:name or title=:name")
//	List<BookEntity> findBYTitleOrAuthor(String name);
//
//	@Query(value = "select * from library.book where book_title=:name or book_author=:name", nativeQuery = true)
//	List<BookEntity> findByTitleOrAuthor(String name);

//	List<BookEntity> findBYTitleOrAuthor(String title, String author);
	
	
	


}
