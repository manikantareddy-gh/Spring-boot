package cfg.lms.repo;

public class UserRepository {

}
