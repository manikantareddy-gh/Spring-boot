package cfg.lms.rowmappers;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import cfg.lms.LibraryManagement.Book;

public class BookRowMapper implements RowMapper<Book> {
    @Override
    public Book mapRow(ResultSet rs, int rowNum) throws SQLException {
        Book book = new Book();
        book.setBook_id(rs.getInt("book_id"));
        book.setBook_title(rs.getString("book_title"));
        book.setBook_author(rs.getString("book_author")); 
        return book;
    }
}
