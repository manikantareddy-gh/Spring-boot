package cfg.lms.LibraryManagement;

import java.sql.Date;

import lombok.Data;

@Data
public class RentedBook {
    private int userId;
    private int bookId;
    private Date rentDate;
}
