package cfg.lms.LibraryManagement;

import lombok.Data;

@Data
public class Users {
	private int user_id;
	private String user_name;
	private String user_email;

}
