package cfg.lms.LibraryManagement;

import lombok.Data;

@Data
public class BookStatus {
    private int statusId;
    private int userId;
    private int bookId;
    private String status; // REQUESTED, APPROVED, etc.
}
