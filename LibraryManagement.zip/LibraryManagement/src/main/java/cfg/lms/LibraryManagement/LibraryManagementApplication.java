package cfg.lms.LibraryManagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class LibraryManagementApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext context = SpringApplication.run(LibraryManagementApplication.class, args);
		BookRespository br = context.getBean(BookRespository.class);
		br.getBooksCount();
		br.getBook("Microservices", "Sara");
		
		br.rateBook(1, 1, 5); // Manikanta rates Java Basics with 5 stars
		br.rateBook(2, 2, 4); // Bhagath rates Spring Boot with 4 stars
		br.rateBook(3, 3, 3); // Vijay rates Data Structures with 3 stars
		
		
		br.updateRequestStatus(1, "APPROVED");
		br.updateRequestStatus(1, "PENDING");
		
		br.rentBook(1, 2);
		
		br.requestBook(1, 3); // Manikanta requests Book 3
		br.requestBook(2, 4); // Bhagath requests Book 4

		br.updateRequestStatus(1, 3, "APPROVED");  // Librarian approves request
		br.updateRequestStatus(2, 4, "REJECTED");  // Librarian rejects request
		br.updateRequestStatus(1, 3, "ASSIGNED");  // Book assigned to Manikanta



	}

}
