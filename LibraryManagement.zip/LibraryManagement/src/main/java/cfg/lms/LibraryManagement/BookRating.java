package cfg.lms.LibraryManagement;

import lombok.Data;

@Data
public class BookRating {
    private int bookId;
    private int userId;
    private int rating;
}
