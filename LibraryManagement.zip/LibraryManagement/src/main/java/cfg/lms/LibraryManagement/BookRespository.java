package cfg.lms.LibraryManagement;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import cfg.lms.rowmappers.BookRowMapper;

@Repository
public class BookRespository {

	@Autowired
	JdbcTemplate template;

	@Autowired
	NamedParameterJdbcTemplate namedTemplate; // ✅ fixed

	public void getBooksCount() {
		int count = template.queryForObject("SELECT COUNT(*) FROM book", Integer.class);
		System.out.println("Total number of books available: " + count);
	}

	public void getBook(String bookTitle, String bookAuthor) {
		MapSqlParameterSource namedParams = new MapSqlParameterSource();
		namedParams.addValue("booktitle", bookTitle);
		namedParams.addValue("bookauthor", bookAuthor);
		List<Book> books = namedTemplate.query(
				"SELECT * FROM book WHERE book_title = :booktitle OR book_author = :bookauthor", namedParams,
				new BookRowMapper());
		for (Book book : books) {
			System.out.println("Book Found: " + book.getBook_title() + " by " + book.getBook_author());
		}
	}
	
	
	public void rateBook(int bookId, int userId, int rating) {
	    // First try to update
	    int rowsUpdated = template.update(
	        "UPDATE book_rating SET rating = ? WHERE book_id = ? AND user_id = ?",
	        rating, bookId, userId
	    );

	    // If not exists, insert new
	    if (rowsUpdated == 0) {
	        template.update(
	            "INSERT INTO book_rating (book_id, user_id, rating) VALUES (?, ?, ?)",
	            bookId, userId, rating
	        );
	    }

	    System.out.println("✅ Rating submitted: Book ID = " + bookId + ", User ID = " + userId + ", Rating = " + rating);
	}
	
	

	
	public void updateRequestStatus(int requestId, String status) {
	    MapSqlParameterSource params = new MapSqlParameterSource();
	    params.addValue("status", status.toUpperCase());
	    params.addValue("requestId", requestId);
	    namedTemplate.update("UPDATE book_request SET status = :status WHERE request_id = :requestId", params);
	    System.out.println("Request #" + requestId + " has been marked as: " + status);
	}
	
	public void rentBook(int userId, int bookId) {
	    String checkSql = "SELECT COUNT(*) FROM rented_book WHERE user_id = ? AND book_id = ?";
	    int count = template.queryForObject(checkSql, Integer.class, userId, bookId);

	    if (count > 0) {
	        System.out.println("⚠️ User already rented this book.");
	        return;
	    }

	    String insertSql = "INSERT INTO rented_book (user_id, book_id, rent_date) VALUES (?, ?, ?)";
	    template.update(insertSql, userId, bookId, new java.sql.Date(System.currentTimeMillis()));
	    System.out.println("✅ Book rented: User ID = " + userId + ", Book ID = " + bookId);
	}

	
	
	public void requestBook(int userId, int bookId) {
	    String sql = "INSERT INTO book_status (user_id, book_id, status) VALUES (?, ?, ?)";
	    template.update(sql, userId, bookId, "REQUESTED");
	    System.out.println("📥 Request submitted: User ID " + userId + " for Book ID " + bookId);
	}
	
	public void updateRequestStatus(int userId, int bookId, String status) {
	    String sql = "UPDATE book_status SET status = ? WHERE user_id = ? AND book_id = ?";
	    int result = template.update(sql, status.toUpperCase(), userId, bookId);
	    
	    if (result > 0) {
	        System.out.println("✅ Request updated: User ID " + userId + ", Book ID " + bookId + " -> " + status.toUpperCase());
	    } else {
	        System.out.println("❌ No matching request to update.");
	    }
	}



	
	
	



}
