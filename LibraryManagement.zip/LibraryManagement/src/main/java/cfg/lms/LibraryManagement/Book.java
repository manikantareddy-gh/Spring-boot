package cfg.lms.LibraryManagement;

import lombok.Data;

@Data
public class Book {
	private int book_id;
	private String book_title;
	private String book_author;

}
